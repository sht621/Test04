package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.mapper.UserMapper;
import com.example.demo.model.UserModel;

@Service
public class UserService {

    private final UserMapper dao;

    public UserService(UserMapper dao) {
        this.dao = dao;
    }

    public boolean insert(UserModel user) {
        return dao.insert(user) > 0;
    }

    public List<UserModel> selectAll() {
        return dao.selectAll();
    }
}
